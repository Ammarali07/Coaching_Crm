---
name: Academic Pulse CRM
colors:
  surface: '#f8f9fb'
  surface-dim: '#d9dadc'
  surface-bright: '#f8f9fb'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f3f4f6'
  surface-container: '#edeef0'
  surface-container-high: '#e7e8ea'
  surface-container-highest: '#e1e2e4'
  on-surface: '#191c1e'
  on-surface-variant: '#444651'
  inverse-surface: '#2e3132'
  inverse-on-surface: '#f0f1f3'
  outline: '#757682'
  outline-variant: '#c5c5d3'
  surface-tint: '#4059aa'
  primary: '#00236f'
  on-primary: '#ffffff'
  primary-container: '#1e3a8a'
  on-primary-container: '#90a8ff'
  inverse-primary: '#b6c4ff'
  secondary: '#9d4300'
  on-secondary: '#ffffff'
  secondary-container: '#fd761a'
  on-secondary-container: '#5c2400'
  tertiary: '#00312c'
  on-tertiary: '#ffffff'
  tertiary-container: '#004942'
  on-tertiary-container: '#4ebdb0'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dce1ff'
  primary-fixed-dim: '#b6c4ff'
  on-primary-fixed: '#00164e'
  on-primary-fixed-variant: '#264191'
  secondary-fixed: '#ffdbca'
  secondary-fixed-dim: '#ffb690'
  on-secondary-fixed: '#341100'
  on-secondary-fixed-variant: '#783200'
  tertiary-fixed: '#89f5e7'
  tertiary-fixed-dim: '#6bd8cb'
  on-tertiary-fixed: '#00201d'
  on-tertiary-fixed-variant: '#005049'
  background: '#f8f9fb'
  on-background: '#191c1e'
  surface-variant: '#e1e2e4'
typography:
  headline-xl:
    fontFamily: Space Grotesk
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-xl-mobile:
    fontFamily: Space Grotesk
    fontSize: 26px
    fontWeight: '700'
    lineHeight: 34px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Space Grotesk
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.015em
  headline-lg-mobile:
    fontFamily: Space Grotesk
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Space Grotesk
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 26px
  stat-display:
    fontFamily: Space Grotesk
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.02em
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
  data-tabular:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 18px
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.04em
  label-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.05em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-desktop: 1.5rem
  margin: 1rem
  margin-tablet: 1.5rem
  margin-desktop: 2rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
  space-2xl: 3rem
---

## Brand & Style

This design system targets administrative staff, academic directors, batch coordinators, and student advisors within coaching institutes preparing 10th and 12th-grade students for competitive and board examinations. The environment must project absolute academic authority, operational discipline, and forward momentum.

The design movement combines **Modern SaaS Functionalism** with **Data-Dense Tactility**:
- **Clarity over ornament:** High signal-to-noise ratio where complex tabular data, attendance percentages, performance percentiles, and fee dues are parsed instantly without visual fatigue.
- **Supportive urgency:** Visual hierarchy isolates operational friction points (e.g., overdue installment alerts, dropping attendance metrics) using high-salience accents while maintaining a calm, reassuring baseline for routine daily workflows.
- **Empathetic professionalism:** Soft card elevations and generous inner-card padding balance out dense student records and rapid-entry form sheets.

## Colors

The palette balances authoritative institution tones with purposeful, urgent accents for operational tracking:

- **Primary (`#1E3A8A`)**: Deep Academy Navy. Governs navigation bars, active filter triggers, primary action buttons, key metrics headings, and high-level analytical tabs.
- **Secondary (`#F97316`)**: Vibrant Amber Orange. Reserved strictly for attention-critical badges, payment-due notifications, high-priority reminders, batch capacity thresholds, and urgent conversion CTAs.
- **Tertiary (`#0D9488`)**: Academic Teal. Used for positive verification metrics: verified enrollments, above-target attendance scores (>= 85%), clearing payments, and successful assignment submissions.
- **Neutral Canvas (`#F3F4F6`)**: Light Cool Slate. The structural base canvas that allows white elevated cards to pop crisply without stark harshness.
- **Surfaces (`#FFFFFF`)**: Pure white reserved for data containers, floating toolbars, modal drawers, and interactive data grid cells.
- **State Semantics**:
  - Critical/Default Due: `#EF4444` (Ruby Red) with `#FEE2E2` tint.
  - Warning/Pending Fee: `#F59E0B` (Warm Amber) with `#FEF3C7` tint.
  - Enrolled/Active: `#10B981` (Emerald) with `#D1FAE5` tint.
  - Prospective/Draft: `#6B7280` (Muted Slate) with `#F3F4F6` tint.

## Typography

Typography establishes an institutional standard. **Space Grotesk** serves headline and metric roles, delivering crisp, modern, geometric authority across executive KPIs, conversion percentages, and cohort grade markers (e.g., "Grade 10 - Batch Alpha").

**Inter** commands all narrative bodies, forms, audit trails, and data matrices. Its neutral, high-legibility glyphs optimize vertical reading rhythm across dense student rosters, fee balance registers, and attendance sheets.

Tabular data cells must enforce proportional tabular figure styling (`font-feature-settings: "tnum" 1`) to ensure numerical alignment across columns containing student ranks, phone contacts, fee amounts, and percentiles.

## Layout & Spacing

The interface employs a **12-column responsive fluid grid** anchored by a persistent vertical navigation shell on desktop views (width: 260px) and a collapsable drawer on mobile.

- **Breakpoints**:
  - `Mobile` (< 768px): 4 columns, `margin: 1rem`, `gutter: 1rem`. Stacks summary stat tiles into a 2-column or 1-column scrollable block.
  - `Tablet` (768px - 1024px): 8 columns, `margin-tablet: 1.5rem`, `gutter: 1rem`. Batches metrics into 2x2 grids; student table views introduce horizontal panning containers with pinned student identity columns.
  - `Desktop` (> 1024px): 12 columns, `margin-desktop: 2rem`, `gutter-desktop: 1.5rem`. Full CRM workflow with simultaneous analytical summaries, filter action ribbons, and comprehensive data tables.

Rhythm is maintained on an 8px base unit. Internal card padding strictly uses `space-lg` (24px) for prominent executive summaries and `space-md` (16px) for compact tabular wrapper cards. Gaps between form controls adhere tightly to `space-sm` (8px) and `space-md` (16px) to maximize screen economy without sacrificing legibility.

## Elevation & Depth

This system avoids aggressive skeuomorphic drops, relying instead on clean, multi-layered visual surfaces:

- **Base Layer (Canvas)**: `#F3F4F6`. Anchors the background without creating glare during extended administrative usage.
- **Card Layer (Default Surface)**: Pure `#FFFFFF` resting on a soft, diffused drop shadow: `0 1px 3px 0 rgba(30, 58, 138, 0.04), 0 1px 2px -1px rgba(30, 58, 138, 0.02)`. Borders utilize a faint hairline stroke: `1px solid rgba(229, 231, 235, 0.8)`.
- **Raised Interactive Layer (Row Hover / Dropdowns / Filter Tooltips)**: Elevation rises dynamically via `0 4px 6px -1px rgba(30, 58, 138, 0.07), 0 2px 4px -2px rgba(30, 58, 138, 0.05)`.
- **Overlay & Modal Drawers (Student Detailed Profile / Fee Collection)**: Top-tier elevation with backdrop blur (`backdrop-filter: blur(4px)`) backed by `rgba(15, 23, 42, 0.4)` and a deep ambient boundary: `0 20px 25px -5px rgba(30, 58, 138, 0.1), 0 8px 10px -6px rgba(30, 58, 138, 0.08)`.

## Shapes

The interface balances structure with contemporary softness:

- **Cards & Data Tables (`rounded-xl` / 16px)**: Encloses major operational domains, KPIs, and data list containers.
- **Input Fields, Search Bars, & Filters (`rounded-lg` / 8px-10px)**: Delivers clear, unambiguous clickable boundaries for rapid data-entry.
- **Status Badges, Tags, & Quick Actions (`rounded-full` / Pill-shape)**: Highlights admission milestones, payment statuses, and quick multi-select filters to distinctly contrast against rectangular data rows.
- **Interactive Buttons (`rounded-lg` / 8px)**: Grounded, sturdy action touchpoints for consistent administrative confidence.

## Components

### Buttons
- **Primary Action**: Deep Navy (`#1E3A8A`) background, white text, 8px border-radius, font-weight 600. On hover: darken by 8% (`#172554`) with subtle y-translation (-1px).
- **Secondary / Urgent CTA**: Vibrant Orange (`#F97316`) background, white text. Reserved for primary operational imperatives like "Record Fee Payment" or "Send Bulk WhatsApp Notice".
- **Outline / Filter Button**: `#FFFFFF` background, `1px solid #D1D5DB`, text `#1F2937`. On hover: border color transitions to `#1E3A8A` with background `#F8FAFC`.

### Badges & Pill Indicators
All badges utilize an ultra-compact `px-2.5 py-0.5` footprint with 11px uppercase bold typography (`label-sm`) and full roundedness:
- **Admission In Review**: Slate fill (`#F1F5F9`), slate text (`#475569`).
- **Enrolled (Grade 10/12)**: Teal tint fill (`#CCFBF1`), deep teal text (`#0F766E`).
- **Fee Overdue**: Crimson tint fill (`#FEE2E2`), red text (`#B91C1C`).
- **Partial Payment Due**: Orange tint fill (`#FFEDD5`), orange text (`#C2410C`).
- **Attendance < 75%**: Warning alert pill accompanied by an inline warning dot indicator (`#EF4444`).

### Data Tables & Student Registers
- **Container**: White surface, 16px rounded corners, faint border (`#E5E7EB`), no internal divider bleed.
- **Header**: Subtle slate fill (`#F8FAFC`), uppercase 11px tracking text, sticky positioning for uninterrupted scrolling.
- **Rows**: Fixed height (52px), subtle hover state transition (`#F8FAFC`). Interactive rows support instant single-click expansion for quick guardian contact details and recent test scores.

### Form Inputs & Filter Triggers
- **Text & Select Fields**: 40px height, `#FFFFFF` background, border `#D1D5DB`, inner horizontal padding 12px. Focus ring: `2px solid #1E3A8A` with a translucent halo (`rgba(30, 58, 138, 0.15)`).
- **Quick Action Filters (Segmented Controls)**: Pill-grouped filters for rapid cohort filtering ("All", "Class 10 CBSE", "Class 12 Science", "Class 12 Commerce", "Fee Defaulters"). Selected state: `#1E3A8A` fill with white text; Unselected state: transparent with `#4B5563` text.

### Summary Metric Cards (KPIs)
- **Structure**: Surface white, `rounded-xl`, padding 20px.
- **Layout**: Top row features an auxiliary label and a tinted status icon badge; middle row presents the prominent Space Grotesk statistic (`stat-display`); bottom row features contextual trend data (e.g., "+4.2% vs last test series" or "14 students pending follow-up").